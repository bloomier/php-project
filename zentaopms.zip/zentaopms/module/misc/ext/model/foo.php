public function foo()
{
    return 'foo';
}
