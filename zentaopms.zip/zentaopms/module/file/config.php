<?php
$config->file->mimes['xml']     = 'text/xml';
$config->file->mimes['html']    = 'text/html';
$config->file->mimes['csv']     = 'text/csv';
$config->file->mimes['default'] = 'application/octet-stream';

$config->file->imageExtensions = array('jpeg', 'jpg', 'gif', 'png');
