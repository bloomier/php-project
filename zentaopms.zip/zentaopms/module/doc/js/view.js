$(function()
{
    var outerH =$('.outer').css('min-height').replace('px', '');
    $('#url-content').height(outerH - 180);
})
