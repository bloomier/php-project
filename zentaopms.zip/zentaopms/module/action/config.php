<?php
$config->action->objectNameFields['product']     = 'name';
$config->action->objectNameFields['story']       = 'title';
$config->action->objectNameFields['productplan'] = 'title';
$config->action->objectNameFields['release']     = 'name';
$config->action->objectNameFields['project']     = 'name';
$config->action->objectNameFields['task']        = 'name';
$config->action->objectNameFields['build']       = 'name';
$config->action->objectNameFields['bug']         = 'title';
$config->action->objectNameFields['testcase']    = 'title';
$config->action->objectNameFields['case']        = 'title';
$config->action->objectNameFields['testtask']    = 'name';
$config->action->objectNameFields['user']        = 'account';
$config->action->objectNameFields['doc']         = 'title';
$config->action->objectNameFields['doclib']      = 'name';
$config->action->objectNameFields['todo']        = 'name';

$config->action->commonImgSize = 870;
