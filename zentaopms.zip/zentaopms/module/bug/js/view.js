function setModal4List(colorboxClass, replaceID)
{
    if(onlybody != 'yes') $('.iframe').modalTrigger({width:900, type:'iframe', afterHide:function(){location.href=location.href;}})
}
