ALTER TABLE `zt_project` DROP `goal`;
